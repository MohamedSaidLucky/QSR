<?php
    require_once("global.php");
    
    require_once("logic/department_controller.php");

    require_once("templates/header.php");

?>
    <!--main content wrapper-->
    <div class="mcw">
        <!--navigation here-->
        <!--main content view-->
        <div class="cv">
            <div class="main-content">
                
                <!-- page title -->
                <h2><i class="fa fa-puzzle-piece"></i> Departments</h2>
                
                <!-- new button -->
                <div>
                    <button class="btn btn-primary add-new-btn" > Add Department </button>
                </div>

                <p>
                    &nbsp;
                </p>

                <!-- Add Form -->
                <div id="add-new-form" class="add-form">
                    <form action="" method="post">
                        <h4> New Department </h4>
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" placeholder="type department name" name="department_name">
                            <div class="input-group-prepend">
                                <button class="btn btn-primary" type="submit" name="new_department" value="true">OK</button>
                                <button class="btn btn-danger cancel-new-form" type="reset">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>

                <!-- list -->
                <!-- <table class="list-table">
                    <tr>
                        <th>#</th>
                        <th>Department Name</th>
                    </tr>
                    <?php

                        foreach($departmentList as $key=>$branch){
                    ?>
                        <tr>
                            <td> </td>
                            <td><?=$branch['department_name']?></td>
                        </tr>
                    <?php
                    }
                    ?>

                <table> -->


                <div class="inbox-bx container-fluid">
                    <div class="row">                            
                        <div class="col-md-12">
                            <table class="table table-stripped">
                                <thead>
                                    <tr>
                                            <td></td>
                                            <th>Branch Name</th>                                                
                                            <td></td>
                                            <td> </td>
                                            <td></td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php

                                    foreach($departmentList as $key=>$department){
                                    ?>
                                        
                                        <tr>
                                            <!-- <td><input type="checkbox" /></td>
                                            <td><i class="fa fa-star"></i></td>
                                            <td><b><?=$department['department_name']?></b></td>
                                            <td><b>In celebration of women and girls everywhere</b></td>
                                            <td></td>
                                            <td>Mar 10</td> -->
                                            <td></td>
                                            <td><b><?=$department['department_name']?></b></td>                                                
                                            <td></td>
                                            <td><i class="fa fa-pencil" ></i> </td>
                                            <td><i class="fa fa-times" ></i></td>
                                    </tr>
                                    <?php
                                    }
                                    ?>
                                    

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>


<?php
    require_once("templates/footer.php");
?>
