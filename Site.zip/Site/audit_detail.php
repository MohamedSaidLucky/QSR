<?php
    require_once("global.php");
    
    require_once("logic/audit_detail_controller.php");

    require_once("templates/header.php");



?>
    <!--main content wrapper-->
    <div class="mcw">
        <!--navigation here-->
        <!--main content view-->
        <div class="cv">
            <div class="main-content">
                
                <!-- page title -->
                <h2><i class="fa fa-light fa-list-check"></i> Audit Detail </h2>
                
                <h3> <?=$auditData['branch_name']?> </h3>
                <h4> <?=$auditData['manager']?> </h4>
                <h5> <?=$auditData['date']?> </h5>                
                <!-- new button -->
                <!-- <div>
                    <button class="btn btn-primary add-new-btn" > New Audit </button>
                </div> -->

                <!-- <p>
                    &nbsp;
                </p> -->
                <div>
                    <h3> Filters </h3>
                    <?=department_combo('',false,'')?>
                    <?=issues_cats_combo('',false,'')?>
                    <?=levels_combo('',false,'')?>
                    <input type="checkbox" id="show_selection_only" />
                <div>
                <!-- Add Form -->
                <div id="add-new-form" class="add-form">
                    <form action="" method="post">
                        
                        <h4> New Branch </h4>
                        <div class="input-group mb-3">
                            <?=branch_combo('',true)?>
                            <input type="text" class="form-control" placeholder="type Manager Name" name="manager">
                            <div class="input-group-prepend">
                                <button class="btn btn-primary" type="submit" name="new_audit" value="true">OK</button>
                                <button class="btn btn-danger cancel-new-form" type="reset">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>

                <!-- list -->
               

            </div>
            <div class="inbox-bx container-fluid">
                <div class="row">                            
                    <div class="col-md-12">
                        <form action="" method="post">
                        <input type="hidden" name="id" value="<?=$_GET['id']?>" />
                        <?php 
                        
                            foreach($departmentList as $index=>$dep){ 
                                $issueList = issue_list([
                                    'department'=>@$dep['department_id']
                                ]);
                            
                        ?>
                        <div class="department dep_<?=@$dep['department_id']?>">
                            <h3><?=$dep['department_name']?></h3>
                            
                            <table class="table table-stripped">
                                
                                <tbody>
                                    <?php

                                    foreach($issueList as $key=>$issue){

                                       
                                    ?>
                                        
                                        <tr class="issue level_<?=$issue['issue_level']?> cat_<?=str_replace(' ','-',$issue['issue_cat'])?>">
                                            
                                            <td><input type="checkbox" class="check" name='issues[]' value='<?=$issue['issue_id']?>' <?=(in_array($issue['issue_id'],$issue_list)?'checked':'')?> /></td>
                                            <td>
                                                
                                                <?=$issue['issue_title']?>
                                                <div>
                                                    <small class="<?=str_replace(' ','-',$issue['issue_cat'])?>" ><?=$issue['issue_cat']?> | <span class="<?=$issue['issue_level']?>"><?=$issue['issue_level']?></span></small>
                                                </div>
                                            </td>
                                            
                                    </tr>
                                    <?php
                                    }
                                    ?>
                                    

                                </tbody>
                            </table>
                        </div>
                        <?php }?>
                        <button type="submit" class="btn btn-primary" name="save_audit" value="ok">Save</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>

<script>

    function filterContent(){
        var dep = $('#departments_combo').val();
        var cat = $('#cats_combo').val().replace(' ','-');
        var level = $('#levels_combo').val();
        
        if(!dep){
            $('.department').show()
        }else{
            $('.department').hide()
            $('.dep_'+dep).show()
        }

        if(!cat && !level){
            $('.issue').show()
        }else{
            
            $('.issue').hide()
            
            if(level && cat ) $('.level_'+level+'.cat_'+cat).show()

            else if(level) $('.level_'+level).show()
            
            else if(cat) $('.cat_'+cat).show()
        }



        console.log(dep,cat,level);
    }

    $('#departments_combo').on('change',filterContent);
    $('#cats_combo').on('change',filterContent);
    $('#levels_combo').on('change',filterContent);


    $('.check').on('click',(e)=>{
        
        var checked= $(e.target).is(':checked')
        
        var tr = $(e.target).closest('tr') ;

        if(checked)
            tr.addClass('tr_selected')
        else
            tr.removeClass('tr_selected')
        
    })

    $('#show_selection_only').on('click',(e)=>{
        
        var checked= $(e.target).is(':checked')

        if(checked)
            $('tr').not('.tr_selected').addClass('tr_not_checked');
        else
            $('tr').removeClass('tr_not_checked');

    })

    function init(){
        $('.check').each((index,item)=>{
            var checked= $(item).is(':checked')
            if(checked)
                $(item).closest('tr').addClass('tr_selected')
        })
    }
    init()



</script>
<?php
    require_once("templates/footer.php");
?>
