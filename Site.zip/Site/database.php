<?php

//Branches

function branch_save($branch_name){
    
    global $con;

    $q= "insert into branch (`branch_name`) values('$branch_name')";
    
    mysqli_query($con,$q) or die(mysqli_error($con));
}

function branch_list( $sort="", $hide=0 ){
    
    
    global $con;

    $q= "select * from branch where 1=1 ";
    
    
    if($hide == 1){
        $q .= " and hide=1";
    }

    if($sort) {
        $q .= " order by $sort asc";
    }

   
    $r = mysqli_query($con,$q) or die(mysqli_error($con));

    $list = array();

    while($row = mysqli_fetch_array($r)){
        $list[] = $row;
    }

    return $list;


}


function department_save($department_name){
    
    global $con;

    $q= "insert into department (`department_name`) values('$department_name')";
    
    mysqli_query($con,$q) or die(mysqli_error($con));
}

function department_list( $sort="", $hide=0 ){
    
    
    global $con;

    $q= "select * from department where 1=1 ";
    
    
    if($hide == 1){
        $q .= " and hide=1";
    }

    if($sort) {
        $q .= " order by $sort asc";
    }

   
    $r = mysqli_query($con,$q) or die(mysqli_error($con));

    $list = array();

    while($row = mysqli_fetch_array($r)){
        $list[] = $row;
    }

    return $list;


}


function level_save($level_label,$score){
    
    global $con;

    $q= "insert into level (`level_label`,`score`) values('$level_label','$score')";
    
    mysqli_query($con,$q) or die(mysqli_error($con));
}

function level_list( $sort="", $hide=0 ){
    
    
    global $con;

    $q= "select * from level where 1=1 ";
    
    
    if($hide == 1){
        $q .= " and hide=1";
    }

    if($sort) {
        $q .= " order by $sort asc";
    }

   
    $r = mysqli_query($con,$q) or die(mysqli_error($con));

    $list = array();

    while($row = mysqli_fetch_array($r)){
        $list[] = $row;
    }

    return $list;


}



function issues_groups_list( $sort="", $hide=0 ){
    
    
    global $con;

    $q= "select * from issues_groups where 1=1 ";
    
    
    if($hide == 1){
        $q .= " and hide=1";
    }

    if($sort) {
        $q .= " order by $sort asc";
    }

   
    $r = mysqli_query($con,$q) or die(mysqli_error($con));

    $list = array();

    while($row = mysqli_fetch_array($r)){
        $list[] = $row;
    }

    return $list;


}

function issues_group_save($group_name){
    
    global $con;

    $q= "insert into issues_groups (`group_name`) values('$group_name')";
    
    mysqli_query($con,$q) or die(mysqli_error($con));
}


function issues_groups_combo($selected='',$class="form-control"){
    
    $groups= issues_groups_list();

    $list = ["<option value='' >Select group</option>"];

    foreach($groups as $group){

        $sel = ($selected == $group['issue_group_id'])?'selected':'';
        
        $list[] = "<option value='$group[issue_group_id]' $sel >$group[group_name]</option>";
    }

    $options = implode('',$list);
    

    $html = "
    <select name='issue_group' class='$class' id='groups_combo'>
    "
    .$options
    ."
    </select>
    ";

    
    return $html;    
}

function issues_cats_combo($selected='',$required=false,$class="form-control"){
    
    $cats= ['Food Safety','Local Standards','Brand Standards'];

    $list = ["<option value='' >Select Category</option>"];

    foreach($cats as $cat){

        $sel = ($selected == $cat)?'selected':'';
        
        $list[] = "<option value='$cat' $sel >$cat</option>";
    }

    $options = implode('',$list);
    

    $html = "
    <select name='issue_cat' class='$class' id='cats_combo'>
    "
    .$options
    ."
    </select>
    ";

    
    return $html;    
}


function levels_combo($selected='',$required=false,$class="form-control"){
    
    $levels= level_list();

    $levels = ['L1','L2','L3'];

    $list = ["<option value='' >Select level</option>"];

    foreach($levels as $level){

        $sel = ($selected == $level)?'selected':'';
        
        $list[] = "<option value='$level' $sel >$level</option>";
    }

    $options = implode('',$list);
    

    $html = "
    <select name='issue_level' class='$class' id='levels_combo'>
    "
    .$options
    ."
    </select>
    ";

    
    return $html;    
}

function department_combo($selected='',$required=false,$class="form-control"){
    
    $departments= department_list();

    $list = ["<option value='' >Select Department</option>"];

    foreach($departments as $dep){

        $sel = ($selected == $dep['department_id'])?'selected':'';
        
        $list[] = "<option value='$dep[department_id]' $sel >$dep[department_name]</option>";
    }

    $options = implode('',$list);
    

    $html = "
    <select name='department' class='$class' id='departments_combo'>
    "
    .$options
    ."
    </select>
    ";

    
    return $html;    
}

function branch_combo($selected='',$required=false,$class="form-control"){
    
    $branches= branch_list();

    $list = ["<option value='' >Select Branch</option>"];

    foreach($branches as $branch){

        $sel = ($selected == $branch['branch_id'])?'selected':'';
        
        $list[] = "<option value='$branch[branch_id]' $sel >$branch[branch_name]</option>";
    }

    $options = implode('',$list);
    

    $html = "
    <select name='branch' id='branch_combo' class='$class' >
    "
    .$options
    ."
    </select>
    ";

    
    return $html;    
}

function year_combo($selected='',$required=false,$class="form-control"){
    
    $branches= branch_list();

    $list = ["<option value='' >Year</option>"];

    for($i=date('Y') ; $i>=date('Y')-5; $i--){

        $sel = ($selected == $i)?'selected':'';
        
        $list[] = "<option value='$i' $sel >$i</option>";
    }

    $options = implode('',$list);
    

    $html = "
    <select name='year' id='year_combo' class='$class' >
    "
    .$options
    ."
    </select>
    ";

    
    return $html;    
}

function month_combo($selected='',$required=false,$class="form-control"){
    
    $branches= branch_list();

    $list = ["<option value='' >Month</option>"];

    for($i=1 ; $i<=12; $i++){

        $sel = ($selected == $i)?'selected':'';
        
        $list[] = "<option value='$i' $sel >$i</option>";
    }

    $options = implode('',$list);
    

    $html = "
    <select name='month' id='month_combo' class='$class' >
    "
    .$options
    ."
    </select>
    ";

    
    return $html;    
}

function issue_save($issue_title,$issue_cat,$issue_level,$department){
    
    global $con;

    $q= "insert into issues (issue_title,issue_cat,issue_level,department) 
            values('$issue_title','$issue_cat','$issue_level','$department')";
    
    mysqli_query($con,$q) or die(mysqli_error($con));
}


function issue_list( $data=[] ){
    
    extract($data);
    
    global $con;

    $where_cat = @$cat? " and issue_cat='$cat' ":"";
    $where_dep = @$department? " and department_id='$department' ":"";
    $where_level = @$level? " and issue_level='$level' ":"";

    $q= "select * from issue_list where 1=1 $where_cat $where_level $where_dep order by department_id, issue_cat, issue_level";
   
    $r = mysqli_query($con,$q) or die(mysqli_error($con));

    $list = array();

    while($row = mysqli_fetch_array($r)){
        $list[] = $row;
    }

    return $list;

}


function audit_list( $sort="", $hide=0 ){
    
    
    global $con;

    $q= "select * from audit_list where 1=1  order by date desc , time desc";
    
    
   

   
    $r = mysqli_query($con,$q) or die(mysqli_error($con));

    $list = array();

    while($row = mysqli_fetch_array($r)){
        $list[] = $row;
    }

    return $list;


}


function audit_save($branch,$manager){
    
    global $con;

    $q= "insert into audit (`branch_id`,`date`,`time`,`manager`) values('$branch',NOW(),NOW(),'$manager')";
    
    

    mysqli_query($con,$q) or die(mysqli_error($con));

    $id= mysqli_insert_id($con);

    return $id;


}

function audit_get($audit_id){
    
    global $con;

    $q= "select * from  audit_list where audit_id='$audit_id'";
    
    $r = mysqli_query($con,$q) or die(mysqli_error($con));

    return mysqli_fetch_array($r);

}


function audit_issue_save($audit_id,$issue_list=[]){
    global $con;
    $issues_str = implode(',', $issue_list);
    echo $q = "delete from audit_issue where issue_id not in($issues_str) and audit_id='$audit_id'";
    mysqli_query($con,$q);

    foreach($issue_list as $key=>$issue){
        $query = "replace into audit_issue values('$audit_id','$issue')";
        mysqli_query($con,$query);

    }
    
}





function audit_issue_list($audit_id){
    
    global $con;
    
    $q = "select * from audit_issue where audit_id='$audit_id'";
    
    $r = mysqli_query($con,$q) or die(mysqli_error($con));

    $list = array();

    while($row = mysqli_fetch_array($r)){
        $list[] = $row['issue_id'];
    }

    return $list;

}


function audit_issue_details($audit_id,$dep_id=NULL){
    
    global $con;

    $where_dep = ($dep_id)? " and department='$dep_id'" : "";
    
    $q = "select * from audit_details where audit_id='$audit_id' $where_dep order by issue_cat , issue_level";
    
    $r = mysqli_query($con,$q) or die(mysqli_error($con));

    $list = array();

    while($row = mysqli_fetch_array($r)){
        $list[] = $row;
    }

    return $list;

}

function audit_count($audit_id){


    global $con;
    
    $levels_degree = ['L1'=>1,'L2'=>3,'L3'=>5];

    $q= "select * from audit_count where audit_id='$audit_id'";
    $r = mysqli_query($con,$q) or die(mysqli_error($con));
    $list = array();

    while($row = mysqli_fetch_array($r)){
        $row['degree'] = $levels_degree[$row['issue_level']] * $row['cnt'];
        $list[] = $row;
    }

    return $list;

}