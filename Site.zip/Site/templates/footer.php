
<footer>
<hr />
<p style="text-align:center">
    Powered By @Mohamed Said
</p>
    <script>
        (function () {
            $('body').toggleClass('msb-x');
            $('#msbo').on('click', function () {
                $('body').toggleClass('msb-x');
            });
        }());
    </script>
</footer>
    <script src="scripts/script.js" ></script>
</body>
</html>

