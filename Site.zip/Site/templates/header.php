<?php
    $currentPage = basename($_SERVER['PHP_SELF'],'.php');
?>


<html>

<head>
    <script src="https://code.jquery.com/jquery-3.1.1.min.js"> </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"> </script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
    <nav class="mnb navbar navbar-default navbar-fixed-top">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
                    aria-expanded="false" aria-controls="navbar">
                    <!-- <span class="sr-only">Toggle navigation</span>
                    <i class="ic fa fa-bars"></i> -->
                    <img src="images/logo.webp" width=50 height=50 />
                </button>
                
                <div style="padding: 30px 10px;font-size:25px">
                    
                    <a href="#" id="msbo" ><i class="ic fa fa-bars"></i></a>
                    
                </div>
            </div>
            <div id="navbar" class="navbar-collapse collapse">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="#">En</a></li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
                            aria-expanded="false">Draude Oba <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="#">Settings</a></li>
                            <li><a href="#">Upgrade</a></li>
                            <li><a href="#">Help</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="#">Logout</a></li>
                        </ul>
                    </li>
                    <li><a href="#"><i class="fa fa-bell-o"></i></a></li>
                    <li><a href="#"><i class="fa fa-comment-o"></i></a></li>
                </ul>
                <form class="navbar-form navbar-right">
                    <input type="text" class="form-control" placeholder="Search...">
                </form>
            </div>
        </div>
    </nav>
    <!--msb: main sidebar-->
    <div class="msb" id="msb" style="padding-left:10px">
        <nav class="navbar navbar-default" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <div class="brand-wrapper">
                    <!-- Brand -->
                    <div class="brand-name-wrapper">
                        <a class="navbar-brand" href="index.php">
                            QSR
                           
                        </a>
                       
                    </div>
                   
                    
                </div>
            
            </div>

            <!-- Main Menu -->
            <div class="side-menu-container">
                <ul class="nav navbar-nav">

                    <li class="<?=($currentPage=='branch')?'active':'' ?>"><a href="branch.php"><i class="fa fa-solid fa-code-branch"></i>Branches </a></li>
                    <li class="<?=($currentPage=='department')?'active':'' ?>"><a href="department.php"> <i class="fa fa-puzzle-piece"></i> Departments</a></li>
                    <!-- <li class="<?=($currentPage=='levels')?'active':'' ?>"><a href="levels.php"><i class="fa fa-sharp fa-light fa-ruler"></i> Levels</a></li> -->
                    <!-- <li class="<?=($currentPage=='issuesgroups')?'active':'' ?>"><a href="issuesgroups.php"><i class="fa fa-sharp fa-solid fa-circle-xmark"></i> Issues Groups</a></li> -->
                    <li class="<?=($currentPage=='issues')?'active':'' ?>"><a href="issues.php"><i class="fa fa-sharp fa-solid fa-circle-xmark"></i> Issues</a></li>
                    <li class="<?=($currentPage=='audit')?'active':'' ?>"><a href="audit.php"><i class="fa fa-sharp fa-light fa-list-check"></i> Audit</a></li>
                    <li><a href="#"><i class="fa fa-user"></i> Users</a></li>
                    <!-- Dropdown-->
                    <li class="panel panel-default" id="dropdown">
                        <a data-toggle="collapse" href="#dropdown-lvl1">
                            <i class="fa fa-diamond"></i> Apps
                            <span class="caret"></span>
                        </a>
                        <!-- Dropdown level 1 -->
                        <div id="dropdown-lvl1" class="panel-collapse collapse">
                            <div class="panel-body">
                                <ul class="nav navbar-nav">
                                    <li><a href="#">Mail</a></li>
                                    <li><a href="#">Calendar</a></li>
                                    <li><a href="#">Ecommerce</a></li>
                                    <li><a href="#">User</a></li>
                                    <li><a href="#">Social</a></li>

                                    <!-- Dropdown level 2 -->
                                    <li class="panel panel-default" id="dropdown">
                                        <a data-toggle="collapse" href="#dropdown-lvl2">
                                            <i class="glyphicon glyphicon-off"></i> Sub Level <span
                                                class="caret"></span>
                                        </a>
                                        <div id="dropdown-lvl2" class="panel-collapse collapse">
                                            <div class="panel-body">
                                                <ul class="nav navbar-nav">
                                                    <li><a href="#">Link</a></li>
                                                    <li><a href="#">Link</a></li>
                                                    <li><a href="#">Link</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li><a href="#"><span class="glyphicon glyphicon-signal"></span> Link</a></li>
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </div>