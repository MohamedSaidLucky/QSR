<?php
    require_once("global.php");
    
    require_once("logic/audit_review_controller.php");

    require_once("templates/header.php");

?>
    <title><?=$auditData['branch_name']?> <?=$auditData['date']?></title>
    <!--main content wrapper-->
    <div class="mcw">
        <!--navigation here-->
        <!--main content view-->
        <div class="cv">
            <div class="main-content">
                
                <!-- page title -->
                <h2 class="page_title"><i class="fa fa-light fa-list-check"></i> Audit Detail </h2>
                <button class="btn btn-danger print">Print</button>
                <h3> <?=$auditData['branch_name']?> </h3>
                <h4> <?=$auditData['manager']?> </h4>
                <h5> <?=$auditData['date']?> </h5>      
                
                <!-- summary -->
                <h3 style="text-align:center;border:solid 1px #eee">  <span id="percentage"> 0 </span> </h3>
                
                <!-- Add Form -->
                <div id="add-new-form" class="add-form">
                    <form action="" method="post">
                        
                        <h4> New Branch </h4>
                        <div class="input-group mb-3">
                            <?=branch_combo('',true)?>
                            <input type="text" class="form-control" placeholder="type Manager Name" name="manager">
                            <div class="input-group-prepend">
                                <button class="btn btn-primary" type="submit" name="new_audit" value="true">OK</button>
                                <button class="btn btn-danger cancel-new-form" type="reset">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>

                <!-- list -->
               

            </div>
            <div class="inbox-bx container-fluid">
                <div class="row">                            
                    <div class="col-md-12">
                        <form action="" method="post">
                        <input type="hidden" name="id" value="<?=$_GET['id']?>" />
                        <?php 
                        
                            foreach($departmentList as $index=>$dep){ 
                                $issueList = audit_issue_details(
                                    $_GET['id']
                                    ,@$dep['department_id']
                                );

                                if(!$issueList) continue;
                            
                        ?>
                        <div class="department dep_<?=@$dep['department_id']?>">
                            <h3><?=$dep['department_name']?></h3>
                            
                            <table class="table table-stripped">
                                
                                <tbody>
                                    <?php

                                    foreach($issueList as $key=>$issue){

                                       
                                    ?>
                                        
                                        <tr class="issue level_<?=$issue['issue_level']?> cat_<?=str_replace(' ','-',$issue['issue_cat'])?>">
                                            
                                            <td>
                                                
                                                <?=$issue['issue_title']?>
                                                <div class="issue_desc">
                                                    <small class="<?=str_replace(' ','-',$issue['issue_cat'])?>" ><?=$issue['issue_cat']?> | <span class="<?=$issue['issue_level']?>"><?=$issue['issue_level']?></span></small>
                                                </div>
                                            </td>
                                            
                                    </tr>
                                    <?php
                                    }
                                    ?>
                                    

                                </tbody>
                            </table>
                        </div>
                        <?php }?>

                        <button type="submit" class="btn btn-primary" name="save_audit" value="ok">Save</button>
                        </form>
                        
                        <h4>Summery<h4>
                        <small>
                        <?php
                            $sum = 0;
                            $analysis = [];
                            $analysis['Food Safety'] = ['L1'=>0,'L3'=>0];
                            $analysis['Local Standards'] = ['L1'=>0,'L2'=>0,'L3'=>0];
                            $analysis['Brand Standards']  = ['L1'=>0,'L2'=>0,'L3'=>0];
                        ?>
                        <table width="100%" style="display:none" > 
                            <?php 

                                foreach($auditCnt as $key=>$val){
                                $sum += $val['degree'];

                                $analysis[$val['issue_cat']][$val['issue_level']] = $val['cnt'];
                            ?>
                                <tr>
                                    <td><?=$val['issue_cat']?> - <?=$val['issue_level']?>:<?=$val['cnt']?></td>
                                    
                                </tr>
                            <?php }
                                
                            ?>
                            <tr>
                                <td></td>
                                <td></td>
                            
                            </tr>
                                    
                        </table>
                        <?php
                            //print_r($analysis);


                        ?>
                        <table width="100%" border=1 style="font-size:.9em; padding:5px">
                            <tr>
                                <th>Food Safety</th>
                                <td>
                                    <div>L1 : <?=$analysis['Food Safety']['L1']?></div>
                                    <div>L3 : <?=$analysis['Food Safety']['L3']?></div>
                                </td>
                                <td >
                                    <?php
                                        if($analysis['Food Safety']['L1']>10 || $analysis['Food Safety']['L3']>=3 ){
                                            echo "UNDER PERFORMING";
                                        }else{
                                            echo "STANDARD";
                                        }
                                    ?>
                                </td>
                            </tr>

                            <tr>
                                <th>Local Standards</th>
                                <td>
                                    <div>L1 : <?=$analysis['Local Standards']['L1']?></div>
                                    <div>L2 : <?=$analysis['Local Standards']['L2']?></div>
                                    <div>L3 : <?=$analysis['Local Standards']['L3']?></div>
                                </td>
                                <td >
                                    <?php
                                        if($analysis['Local Standards']['L1']>6 ||  $analysis['Local Standards']['L2']>5 || $analysis['Local Standards']['L3']>5 ){
                                            echo "UNDER PERFORMING";
                                        }
                                        elseif($analysis['Local Standards']['L1']>4 ||  $analysis['Local Standards']['L2']>4 || $analysis['Local Standards']['L3']>3 )
                                        {
                                            echo "MARGINER";
                                        }
                                        else{
                                            echo "STANDARD";
                                        }
                                    ?>
                                </td>
                            </tr>

                            <tr>
                                <th>Brand Standards</th>
                                <td>
                                    <div>L1 : <?=$analysis['Local Standards']['L1']?></div>
                                    <div>L2 : <?=$analysis['Local Standards']['L2']?></div>
                                    <div>L3 : <?=$analysis['Local Standards']['L3']?></div>
                                </td>
                                <td >
                                    <?php
                                        if($analysis['Brand Standards']['L1']>6 ||  $analysis['Brand Standards']['L2']>5 || $analysis['Brand Standards']['L3']>5 ){
                                            echo "UNDER PERFORMING";
                                        }
                                        elseif($analysis['Brand Standards']['L1']>4 ||  $analysis['Brand Standards']['L2']>4 || $analysis['Brand Standards']['L3']>3 )
                                        {
                                            echo "MARGINER";
                                        }
                                        else{
                                            echo "STANDARD";
                                        }
                                    ?>
                                </td>
                            </tr>
                        </table>
                        <small>


                    </div>
                </div>
            </div>
        </div>
    </div>

<script>

    function filterContent(){
        var dep = $('#departments_combo').val();
        var cat = $('#cats_combo').val().replace(' ','-');
        var level = $('#levels_combo').val();
        
        if(!dep){
            $('.department').show()
        }else{
            $('.department').hide()
            $('.dep_'+dep).show()
        }

        if(!cat && !level){
            $('.issue').show()
        }else{
            
            $('.issue').hide()
            
            if(level && cat ) $('.level_'+level+'.cat_'+cat).show()

            else if(level) $('.level_'+level).show()
            
            else if(cat) $('.cat_'+cat).show()
        }



        console.log(dep,cat,level);
    }

    $('#departments_combo').on('change',filterContent);
    $('#cats_combo').on('change',filterContent);
    $('#levels_combo').on('change',filterContent);

    $('#percentage').text(<?=(100-$sum)?> + '%')

    $('.print').on('click',()=>{
        print()
    })

</script>
<?php
    require_once("templates/footer.php");
?>
