<?php
    require_once("global.php");
    
    require_once("logic/audit_controller.php");

    require_once("templates/header.php");

?>
    <!--main content wrapper-->
    <div class="mcw">
        <!--navigation here-->
        <!--main content view-->
        <div class="cv">
            <div class="main-content">
                
                <!-- page title -->
                <h2><i class="fa fa-light fa-list-check"></i> Audit </h2>
                
                <!-- new button -->
                <div>
                    <button class="btn btn-primary add-new-btn" > New Audit </button>
                </div>

                <p>
                    &nbsp;
                </p>

                <!-- Add Form -->
                <div id="add-new-form" class="add-form">
                    <form action="" method="post">
                        <h4> New Branch </h4>
                        <div class="input-group mb-3">
                            <?=branch_combo('',true)?>
                            <input type="text" class="form-control" placeholder="type Manager Name" name="manager">
                            <div class="input-group-prepend">
                                <button class="btn btn-primary" type="submit" name="new_audit" value="true">OK</button>
                                <button class="btn btn-danger cancel-new-form" type="reset">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>

                <!-- list -->
               

            </div>
            
            <div class="inbox-bx container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <h4>Filter</h4>
                        <div>
                            <?=branch_combo('',false,'select branch')?>
                            <?=month_combo(date('n'),false,'select')?>
                            <?=year_combo(date('Y'),false,'select')?>
                        </div>
                    </div>                
                </div>
                <div class="row">                            
                    <div class="col-md-12">
                        <table class="table table-stripped">
                            <thead>
                                <tr>
                                        <td></td>
                                        <th>Branch</th>                                                
                                        <th>Date </th>
                                        <th>Manager </th>
                                        <th>Score</th>
                                        <td></td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php

                                foreach($auditList as $key=>$audit){

                                    $d = strtotime($audit['date']);
                                    $y = date('Y',$d);
                                    $m = date('n',$d);
                                ?>
                                    
                                    <tr class='audit_row b_<?=$audit['branch_id']?> y_<?=$y?> m_<?=$m?>'>

                                        
                                        <td></td>
                                        <td><a href="audit_detail.php?id=<?=$audit['audit_id']?>"><?=$audit['branch_name']?></a></td>                                                
                                        <td><?=date("d/m/Y",strtotime($audit['date'])) ?></td>
                                        <td><?=$audit['manager']?></td>
                                        <td><?=$audit['score']?>%</td>
                                        <td><i class="fa fa-times" ></i></td>
                                    </tr>
                                <?php
                                }
                                ?>
                                

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script>
        
        function filterContent(){
            
            
            var b = $('.branch').val();
            var m = $('#month_combo').val().replace(' ','-');
            var y = $('#year_combo').val();
            
            

            var selector = '';

            selector +=b?'.b_'+b:'';
            selector +=m?'.m_'+m:'';
            selector +=y?'.y_'+y:''; 
            
            $('.audit_row').hide();
            
            if(selector)
                $(selector).show();
            else
                $('.audit_row').show();

        
            console.log(selector);

            localStorage.setItem('b', b);
            localStorage.setItem('m', m);
            localStorage.setItem('y', y);
        }

        function initFilterForm(){
            
            $('.branch').val(localStorage.getItem('b'));
            $('#month_combo').val(localStorage.getItem('m'));
            $('#year_combo').val(localStorage.getItem('y'));
            filterContent()

        }
        

    
        initFilterForm();

        $('.select').on('change',filterContent);
   
    </script>

<?php
    require_once("templates/footer.php");
?>
