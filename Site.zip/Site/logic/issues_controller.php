<?php



//New Branch
if(@$_POST['new_issue']){   
    extract($_POST);    
    issue_save($issue_title,$issue_cat,$issue_level,$department);
    //header("Loc")
    //print_r($_POST);
}



//get branch list
$issueList = issue_list([
    'level'=>@$_GET['issue_level'],
    'department'=>@$_GET['department'],
    'cat'=>@$_GET['issue_cat'],


]);





