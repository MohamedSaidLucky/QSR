<?php



//New Branch
if(@$_POST['save_audit']){       
    
    //audit_save($_POST['branch'],$_POST['manager']);
    //print_r($_POST);

    audit_issue_save($_POST['id'],$_POST['issues']);



}



//get branch list
$auditList = audit_list();

//
$departmentList = department_list();

$auditData = audit_get($_GET['id']);

$issue_list = audit_issue_list($_GET['id']);


$auditCnt = audit_count($_GET['id']);










