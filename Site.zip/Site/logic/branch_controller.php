<?php



//New Branch
if(@$_POST['new_branch']){       
    branch_save($_POST['branch_name']);
}



//get branch list
$branchList = branch_list();



