<?php



//New Branch
if(@$_POST['new_audit']){       
    
    $id= audit_save($_POST['branch'],$_POST['manager']);

    header("Location: audit_detail.php?id=$id");


}

//get branch list
$auditList = audit_list();





