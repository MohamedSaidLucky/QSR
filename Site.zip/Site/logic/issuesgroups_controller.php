<?php



//New Branch
if(@$_POST['new_group']){       
    issues_group_save($_POST['group_name']);
}



//get branch list
$issuesGroupsList = issues_groups_list();





