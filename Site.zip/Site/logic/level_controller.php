<?php



//New Branch
if(@$_POST['new_level']){       
    
    level_save($_POST['level_label'],$_POST['score']);

}



//get branch list
$levelList = level_list();





