<?php



//New Branch
if(@$_POST['new_department']){       
    department_save($_POST['department_name']);
}



//get branch list
$departmentList = department_list();





