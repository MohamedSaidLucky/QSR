<html>
    <head>
        <style>

@keyframes example {
  from {scale: 0;}
  to {scale: 1;}
  eas
}

div {
  width: 100px;
  height: 100px;
  background-color: red;
  animation: example 1s ease-in-out;
  
}

        </style>
    </head>
    <body>
        <div>
            Hello world!
        </div>
    </body>
</html>