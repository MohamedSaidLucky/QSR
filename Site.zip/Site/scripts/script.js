$('.add-new-btn').on('click',()=>{
    $('#add-new-form').show();
    $('#show-form').hide();
})

$('.cancel-new-form').on('click',()=>{
    $('#add-new-form').hide();
    
})


$('#show-form').toggle();

$('.filter-btn').on('click',()=>{
    $('#show-form').toggle();
    $('#add-new-form').hide();
})