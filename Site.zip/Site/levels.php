<?php
    require_once("global.php");
    
    require_once("logic/level_controller.php");

    require_once("templates/header.php");

?>
    <!--main content wrapper-->
    <div class="mcw">
        <!--navigation here-->
        <!--main content view-->
        <div class="cv">
            <div class="main-content">
                
                <!-- page title -->
                <h2><i class="fa fa-sharp fa-light fa-ruler"></i> Levels</h2>
                
                <!-- new button -->
                <div>
                    <button class="btn btn-primary add-new-btn" > Add Level </button>
                </div>

                <p>
                    &nbsp;
                </p>

                <!-- Add Form -->
                <div id="add-new-form" class="add-form">
                    <form action="" method="post">
                        <h4> New Level </h4>
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" placeholder="type level name" name="level_label">
                            <input type="text" class="form-control" size="5" placeholder="type points" name="score">
                            <div class="input-group-prepend">
                                <button class="btn btn-primary" type="submit" name="new_level" value="true">OK</button>
                                <button class="btn btn-danger cancel-new-form" type="reset">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>

                <!-- list -->
                <!-- <table class="list-table">
                    <tr>
                        <th>#</th>
                        <th>Level Label</th>
                        <th>Score</th>
                    </tr>
                    <?php

                        foreach($levelList as $key=>$level){
                    ?>
                        <tr>
                            <td> </td>
                            <td><?=$level['level_label']?></td>
                            <td><?=$level['score']?></td>
                        </tr>
                    <?php
                    }
                    ?>

                <table> -->

                <div class="inbox-bx container-fluid">
                    <div class="row">                            
                        <div class="col-md-12">
                            <table class="table table-stripped">
                                <thead>
                                    <tr>
                                            <td></td>
                                            <th>Level Name</th>                                                
                                            <th>Score </th>
                                            <td> </td>
                                            <td></td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php

                                    foreach($levelList as $key=>$level){
                                    ?>
                                        
                                        <tr>
                                            <!-- <td><input type="checkbox" /></td>
                                            <td><i class="fa fa-star"></i></td>
                                            <td><b><?=$department['department_name']?></b></td>
                                            <td><b>In celebration of women and girls everywhere</b></td>
                                            <td></td>
                                            <td>Mar 10</td> -->
                                            <td></td>
                                            <td><b><?=$level['level_label']?></b></td>                                                
                                            <td><b><?=$level['score']?></b></td>
                                            <td><i class="fa fa-pencil" ></i> </td>
                                            <td><i class="fa fa-times" ></i></td>
                                    </tr>
                                    <?php
                                    }
                                    ?>
                                    

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>


<?php
    require_once("templates/footer.php");
?>
