<?php
    require_once("global.php");
    
    require_once("logic/branch_controller.php");

    require_once("templates/header.php");

?>
    <!--main content wrapper-->
    <div class="mcw">
        <!--navigation here-->
        <!--main content view-->
        <div class="cv">
            <div class="main-content">
                
                <!-- page title -->
                <h2><i class="fa fa-solid fa-code-branch"></i> Branches</h2>
                
                <!-- new button -->
                <div>
                    <button class="btn btn-primary add-new-btn" > Add Branch </button>
                </div>

                <p>
                    &nbsp;
                </p>

                <!-- Add Form -->
                <div id="add-new-form" class="add-form">
                    <form action="" method="post">
                        <h4> New Branch </h4>
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" placeholder="type branch name" name="branch_name">
                            <div class="input-group-prepend">
                                <button class="btn btn-primary" type="submit" name="new_branch" value="true">OK</button>
                                <button class="btn btn-danger cancel-new-form" type="reset">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>

                <!-- list -->
                <table class="list-table" style="display:none">
                    <tr>
                        <th>#</th>
                        <th>Branch Name</th>
                    </tr>
                    <?php

                    foreach($branchList as $key=>$branch){
                    ?>
                        <tr>
                            <td> </td>
                            <td><?=$branch['branch_name']?></td>
                        </tr>
                    <?php
                    }
                    ?>

                <table>

            </div>
            <div class="inbox-bx container-fluid">
                        <div class="row">                            
                            <div class="col-md-12">
                                <table class="table table-stripped">
                                    <thead>
                                        <tr>
                                                <td></td>
                                                <th>Branch Name</th>                                                
                                                <td></td>
                                                <td> </td>
                                                <td></td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php

                                        foreach($branchList as $key=>$branch){
                                        ?>
                                            
                                            <tr>
                                                <!-- <td><input type="checkbox" /></td>
                                                <td><i class="fa fa-star"></i></td>
                                                <td><b><?=$branch['branch_name']?></b></td>
                                                <td><b>In celebration of women and girls everywhere</b></td>
                                                <td></td>
                                                <td>Mar 10</td> -->
                                                <td></td>
                                                <td><b><?=$branch['branch_name']?></b></td>                                                
                                                <td></td>
                                                <td><i class="fa fa-pencil" ></i> </td>
                                                <td><i class="fa fa-times" ></i></td>
                                        </tr>
                                        <?php
                                        }
                                        ?>
                                        

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
        </div>
    </div>


<?php
    require_once("templates/footer.php");
?>
