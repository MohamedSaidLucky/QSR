<?php

    $SERVER     = "localhost";
    
    $DBNAME     = "qsr";
    
    $USERNAME   = "root";

    $PASSWORD   = "";

    $con = mysqli_connect($SERVER,$USERNAME,$PASSWORD);

    if($con){
    
        mysqli_select_db($con,$DBNAME) or die('databse not found');
    
    }else{
    
        die("Connection failed: " . mysqli_connect_error());
    
    }