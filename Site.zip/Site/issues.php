<?php
    require_once("global.php");
    
    require_once("logic/issues_controller.php");

    require_once("templates/header.php");

?>
    <!--main content wrapper-->
    <div class="mcw">
        <!--navigation here-->
        <!--main content view-->
        <div class="cv">
            <div class="main-content">
                
                <!-- page title -->
                <h2><i class="fa fa-sharp fa-solid fa-circle-xmark"></i> Issues</h2>
                
                <!-- new button -->
                <div>
                    <button class="btn btn-primary add-new-btn" > Add Issue </button>
                    <button class="btn btn-info filter-btn" > <i class="fa fa-filter" aria-hidden="true"></i> </button>
                </div>

                <p>
                    &nbsp;
                </p>
                
                <!-- Add Form -->
                <div id="add-new-form" class="add-form">
                    <form action="" method="post">
                        <h4> New Issue </h4>
                        <div class="input-group mb-3">
                            
                            <input required type="text" class="form-control" placeholder="type Description" name="issue_title">

                            <?php
                                echo "<p>";
                                echo "<br/><br/>";
                                echo issues_cats_combo(@$_GET['issue_cat']);
                                echo "<br/><br/>";
                                echo levels_combo(@$_GET['issue_level']);
                                echo "<br/><br/>";
                                echo department_combo(@$_GET['department']);
                                echo "<br/><br/>";
                                echo "</p>";
                            ?>
                            
                            <div class="input-group-prepend">
                                <button class="btn btn-primary" type="submit" name="new_issue" value="true">OK</button>
                                <button class="btn btn-danger cancel-new-form" type="reset">Cancel</button>
                            </div>
                        </div>
                    </form>
                </div>

                <!-- list -->
                
                <div id="show-form">
                    <form class="form-inline" action="?">
                        <h3>Filter </h3>
                        <div class="form-group">
                            <?=department_combo(@$_GET['department'])?>
                        </div>
                        <div class="form-group">
                            <?=issues_cats_combo(@$_GET['issue_cat'])?>
                        </div>
                        <div class="form-group">
                            <?=levels_combo(@$_GET['issue_level'])?>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-info">Search</button>
                        </div>
                        
                    </form>
                </div>                
                <div class="inbox-bx container-fluid">
                    <div class="row">                            
                        <div class="col-md-12">
                        
                            <table class="table table-stripped">
                                <thead>
                                    <tr>
                                            <td></td>
                                            <th>Issue</th>                                                
                                            <th>Level </th>
                                            <td> </td>
                                            <td></td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php

                                    foreach($issueList as $key=>$level){
                                    ?>
                                        
                                        <tr>
                                           
                                            <td><?=$level['department_name']?></td>
                                            <td>
                                                <?=$level['issue_title']?><br/>
                                                <small class="<?=str_replace(' ','-',$level['issue_cat'])?>" ><?=$level['issue_cat']?> | <span class="<?=$level['issue_level']?>"><?=$level['issue_level']?></span></small>
                                            </td>

                                            <td></td>
                                            <td><i class="fa fa-pencil" ></i> </td>
                                            <td><i class="fa fa-times" ></i></td>
                                        </tr>
                                    <?php
                                    }
                                    ?>
                                    

                                </tbody>
                            </table>
                                    
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php
    require_once("templates/footer.php");
?>
