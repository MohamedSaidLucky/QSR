<?php
    require_once("templates/header.php");
?>
    <!--main content wrapper-->
    <div class="mcw">
        <!--navigation here-->
        <!--main content view-->
        <div class="cv">
            <div class="main-content">
                <h2>Levels</h2>
                <div>
                    <button class="btn btn-primary"> Add Level </button>
                </div>
            </div>
        </div>
    </div>


<?php
    require_once("templates/footer.php");
?>